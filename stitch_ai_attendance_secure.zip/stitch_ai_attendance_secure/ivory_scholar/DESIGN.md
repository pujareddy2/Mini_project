# Design System Strategy: The Academic Atelier

## 1. Overview & Creative North Star
The "Academic Atelier" is the North Star for this design system. It moves away from the sterile, rigid grids of traditional enterprise software and toward the feel of a high-end, curated academic journal. This system is defined by **"Breatheable Authority"**—it is professional and trustworthy, yet possesses a lightness that prevents the administrative burden of attendance tracking from feeling heavy.

We break the "template" look through **Intentional Asymmetry** and **Tonal Depth**. Instead of a centered, boxed-in layout, we use wide margins, varied column widths, and "The Layering Principle" to create an environment that feels more like a physical workspace than a digital database.

## 2. Colors: Tonal Architecture
This system relies on a sophisticated palette of muted blues and layered neutrals. We do not use color to "decorate"; we use it to define hierarchy and focus.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders for sectioning or layout containment. 
*   **The Method:** Boundaries must be defined solely through background color shifts. A `surface-container-low` section sitting on a `surface` background provides all the definition needed.
*   **The Goal:** To create a seamless, high-fidelity experience that feels "carved" rather than "outlined."

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. Use the Material tiers to create depth:
*   **Base Layer:** `surface` (#F8F9FA)
*   **Sectioning:** `surface-container-low` (#F1F4F5) for secondary content areas.
*   **Interactive Cards:** `surface-container-lowest` (#FFFFFF) for primary data points to make them "pop" against the gray base.
*   **Active Overlays:** `surface-container-high` (#E5E9EB) for elements that require immediate attention.

### The "Glass & Gradient" Rule
To elevate the brand beyond a "flat" UI:
*   **CTAs:** Use a subtle linear gradient on primary buttons (from `primary` to `primary_dim`) to add a tactile, convex feel.
*   **Floating Navigation:** Use **Glassmorphism** for sidebars or top navigation. Apply a semi-transparent `surface` color with a `backdrop-blur` of 12px–20px. This allows the "soul" of the background content to bleed through, softening the interface.

## 3. Typography: The Editorial Voice
We utilize a high-contrast scale to separate "Data" from "Direction."

*   **Public Sans (Headings):** This is our "Authoritative" voice. Use `display-lg` and `headline-md` with generous tracking (-0.02em) to create a premium, editorial look for dashboards and reports.
*   **Inter (Body):** Our "Functional" voice. Inter is chosen for its exceptional legibility in dense data environments (attendance lists, timestamps). 
*   **Hierarchy as Identity:** By pairing a large, bold `headline-lg` in Public Sans with a quiet, regular `body-md` in Inter, we create a sense of trust and clarity. Avoid "middle-ground" sizes; go big for impact or small for utility.

## 4. Elevation & Depth
In this system, depth is a function of light and layering, not shadows.

*   **The Layering Principle:** Place a `surface-container-lowest` card on a `surface-container-low` section. This 2-point hex shift creates a "Soft Lift" that feels natural and premium without the visual clutter of a shadow.
*   **Ambient Shadows:** If a floating element (like a modal or dropdown) requires a shadow, it must be "Ambient."
    *   **Blur:** 24px - 40px.
    *   **Opacity:** 4% - 6%.
    *   **Color:** Use a tinted version of `on-surface` (a deep slate blue) rather than pure black.
*   **The "Ghost Border" Fallback:** If accessibility requires a border (e.g., input fields), use the `outline-variant` token at **15% opacity**. A 100% opaque border is a failure of the design system.

## 5. Components: The Refined Toolkit

### Buttons
*   **Primary:** Pill-shaped (`rounded-full`) using the `primary` to `primary_dim` gradient. High-contrast `on_primary` text.
*   **Secondary:** No background. Use `primary` text with a `surface-container-high` background on hover only.
*   **Tertiary:** `label-md` text style, underlined only on hover.

### Inputs & Text Areas
*   **Style:** No heavy borders. Use `surface-container-highest` as a solid background fill with a bottom-only 2px "focus bar" using the `primary` color that animates from the center on focus.

### Cards & Lists (The Verimark Standard)
*   **Anti-Divider Policy:** Forbid the use of horizontal rules (`<hr>`). 
*   **The Alternative:** Separate list items using 12px of vertical white space (from the spacing scale) or alternating background shifts (`surface` to `surface-container-low`). 

### Attendance Chips
*   **Status Indicators:** Use the pastel accents. "Present" uses a soft teal tint, "Absent" uses a muted `error_container` (#FA746F) at 20% opacity. Avoid saturated "Traffic Light" colors.

### The "Academic Breadcrumb"
*   A custom component for Verimark. Instead of standard `Home > Class > Student`, use a vertical "Timeline" breadcrumb in the sidebar that uses `surface-tint` to show the user's current depth in the academic hierarchy.

## 6. Do’s and Don’ts

### Do
*   **Do** use white space as a structural element. If a screen feels "busy," increase the padding rather than adding a border.
*   **Do** use `title-lg` for student names to give them importance.
*   **Do** ensure all interactive elements have a minimum 44px tap target, even if the visual element is smaller.

### Don't
*   **Don't** use pure black (#000000) for text. Always use `on_surface` (#2D3335) to maintain the soft, high-fidelity aesthetic.
*   **Don't** use "Glow" or "Neon" effects. This is a system of light and paper, not electricity.
*   **Don't** stack more than three levels of surface containers. Too much nesting creates "Visual Fatigue."